﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace SaleBook.admin
{
    public partial class login : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=E:\WEBASPNET\SaleBook\SaleBook\App_Data\bookstore.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
        }

        protected void btn_signin_Click(object sender, EventArgs e)
        {
            //int i = 0;
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from staff where username='" + txt_username.Text + "' and password='" + txt_password.Text + "'";
            
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            //i = Convert.ToInt32(dt.Rows.Count.ToString());


            if (txt_username.Text=="admin" && txt_password.Text=="admin")
            {
                Response.Redirect("demo.aspx");
            }
            else
            {
                error.Style.Add("display", "block");
            }
        }
    }
}