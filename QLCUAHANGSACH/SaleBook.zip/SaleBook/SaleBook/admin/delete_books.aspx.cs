﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace SaleBook.admin
{
    public partial class delete_books : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=E:\WEBASPNET\SaleBook\SaleBook\App_Data\bookstore.mdf;Integrated Security=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            if (Request.QueryString["book_id"] == null)
            {
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete books where book_id='" + Request.QueryString["id"].ToString() + "'";
                cmd.ExecuteNonQuery();
            }
            Response.Redirect("display_all_books.aspx");
        }
    }
}