﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace SaleBook.admin
{
    public partial class edit_books : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=E:\WEBASPNET\SaleBook\SaleBook\App_Data\bookstore.mdf;Integrated Security=True");
        int book_id; 
        protected void Page_Load(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            book_id = Convert.ToInt32(Request.QueryString["book_id"]);

            if (IsPostBack) return;

            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from books where book_id =" + book_id + "";
            cmd.ExecuteNonQuery();
            
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                //txt_bookid.Text = dr["book_id"].ToString();
                txt_booktitle.Text = dr["book_title"].ToString();
                txt_authorname.Text = dr["book_author"].ToString();
                txt_publishcompany.Text = dr["publishing_company"].ToString();
                txt_bookcategory.Text = dr["book_category"].ToString();
                txt_pricepurchase.Text = dr["book_price_purchased"].ToString();
                txt_pricesold.Text = dr["book_price_sold"].ToString();
                txt_qty.Text = dr["avaliable_qty"].ToString();
                txt_bookimage.Text = dr["book_image"].ToString();
            }

        }

        protected void btn_update_Click(object sender, EventArgs e)
        {
            string books_image_name = "";

            string path = "";


            if (f1.FileName.ToString() != "")
            {
                books_image_name = Class1.GetRandomPassword(10) + ".jpg";
                f1.SaveAs(Request.PhysicalApplicationPath + "/admin/books_images/" + books_image_name.ToString());
                path = "books_images/" + books_image_name.ToString();

                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update books set book_title= N'" + txt_booktitle.Text + "',book_image='" + path.ToString() + "',book_author=N'" + txt_authorname.Text + "',publishing_company=N'" + txt_publishcompany.Text + "',book_category=N'" + txt_bookcategory.Text + "',book_price_purchased='" + txt_pricepurchase.Text + "',book_price_sold='" + txt_pricesold.Text + "',avaliable_qty='" + txt_qty.Text + "' where book_id=" + book_id;
                cmd.ExecuteNonQuery();

            }

            if (f1.FileName.ToString() == "")
            {
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update books set book_title= N'" + txt_booktitle.Text + "',book_author=N'" + txt_authorname.Text + "',publishing_company=N'" + txt_publishcompany.Text + "',book_category=N'" + txt_bookcategory.Text + "',book_price_purchased='" + txt_pricepurchase.Text + "',book_price_sold='" + txt_pricesold.Text + "',avaliable_qty='" + txt_qty.Text + "' where book_id=" + book_id;
                cmd.ExecuteNonQuery();
            }

            Response.Redirect("display_all_books.aspx");
        }
    }
}